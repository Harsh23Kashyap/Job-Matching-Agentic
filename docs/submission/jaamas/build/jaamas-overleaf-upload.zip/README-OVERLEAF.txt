JAAMAS Overleaf upload package
==============================

Compile: manuscript/main.tex with pdfLaTeX + BibTeX (sn-mathphys-num.bst).

Directory layout:
  manuscript/main.tex
  manuscript/sections/*.tex
  manuscript/tables/*.tex
  figures/Fig1.pdf ... Fig5.pdf

Do NOT add main-preprint.tex or archive/ contents to this project.
